package com.samwong.wordlens;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

/*
 * Selection screen for the prototype. The current frame is obtained from the
 * projection service. This class sends a normalized selection rectangle back.
 */
public class CropActivity extends AppCompatActivity {
    SelectionView selection;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this);root.setOrientation(1);
        TextView hint=new TextView(this);hint.setText("請喺畫面預覽上拖動框選一次識別區域");hint.setPadding(12,12,12,12);root.addView(hint);
        selection=new SelectionView(this);root.addView(selection,new LinearLayout.LayoutParams(-1,0,1));
        Button ok=new Button(this);ok.setText("確認選取");root.addView(ok);
        ok.setOnClickListener(v->{
            RectF n=selection.normalized();
            Intent i=new Intent(this,ContinuousCaptureService.class);
            i.setAction("SET_REGION");i.putExtra("left",n.left);i.putExtra("top",n.top);i.putExtra("right",n.right);i.putExtra("bottom",n.bottom);
            startService(i);
            Toast.makeText(this,"已設定區域；識別服務會持續運作",Toast.LENGTH_LONG).show();
            finish();
        });
        setContentView(root);
    }
    class SelectionView extends View{
        Paint p=new Paint(3);float sx,sy,ex,ey;boolean moved=false;
        RectF imageRect=new RectF();
        SelectionView(Context c){super(c);setBackgroundColor(0xFF111827);}
        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            if(CropActivity.bitmap!=null){
                float scale=Math.min(getWidth()/(float)CropActivity.bitmap.getWidth(),getHeight()/(float)CropActivity.bitmap.getHeight());
                float w=CropActivity.bitmap.getWidth()*scale,h=CropActivity.bitmap.getHeight()*scale;
                imageRect.set((getWidth()-w)/2f,(getHeight()-h)/2f,(getWidth()+w)/2f,(getHeight()+h)/2f);
                p.setColor(Color.WHITE);c.drawBitmap(CropActivity.bitmap,null,imageRect,p);
            } else {p.setColor(Color.WHITE);p.setTextSize(18);c.drawText("等待螢幕預覽…",24,40,p);}
            if(moved){p.setColor(0x553B82F6);c.drawRect(sx,sy,ex,ey,p);p.setColor(0xFFFFFF00);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawRect(sx,sy,ex,ey,p);p.setStyle(Paint.Style.FILL);}
        }
        @Override public boolean onTouchEvent(android.view.MotionEvent e){
            if(e.getAction()==MotionEvent.ACTION_DOWN){sx=ex=e.getX();sy=ey=e.getY();moved=true;invalidate();return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE||e.getAction()==MotionEvent.ACTION_UP){ex=e.getX();ey=e.getY();invalidate();return true;}
            return true;
        }
        RectF normalized(){
            if(CropActivity.bitmap==null)return new RectF(0,0,1,1);
            float scale=Math.min(getWidth()/(float)CropActivity.bitmap.getWidth(),getHeight()/(float)CropActivity.bitmap.getHeight());
            float w=CropActivity.bitmap.getWidth()*scale,h=CropActivity.bitmap.getHeight()*scale;
            float ox=(getWidth()-w)/2f,oy=(getHeight()-h)/2f;
            float l=(Math.min(sx,ex)-ox)/Math.max(1,w),t=(Math.min(sy,ey)-oy)/Math.max(1,h);
            float r=(Math.max(sx,ex)-ox)/Math.max(1,w),b=(Math.max(sy,ey)-oy)/Math.max(1,h);
            return new RectF(Math.max(0,Math.min(1,l)),Math.max(0,Math.min(1,t)),Math.max(0,Math.min(1,r)),Math.max(0,Math.min(1,b)));
        }
    }
}
