package com.samwong.wordlens;
import java.util.*;
public final class SuggestionFormatter {
    private SuggestionFormatter(){}
    public static String format(String text){
        StringBuilder out=new StringBuilder("持續識別結果\n").append(text).append("\n\n可組成嘅單字：\n");
        LinkedHashSet<String> words=new LinkedHashSet<>();
        for(String token:text.split("[^A-Za-z]+"))if(token.length()>=2)words.add(token.toLowerCase(Locale.ROOT));
        int count=0;
        for(String w:words){
            out.append("\n").append(w.toUpperCase(Locale.ROOT)).append(" → ");
            List<String> matches=WordFinder.find(w);
            if(matches.isEmpty())out.append("字典暫無配對");
            else out.append(String.join(", ",matches.subList(0,Math.min(12,matches.size()))));
            out.append("\n");
            if(++count>=8)break;
        }
        return out.toString();
    }
}
