package com.samwong.wordlens;

import android.app.*;
import android.content.*;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    static final int REQ_OVERLAY=2001, REQ_CAPTURE=2002;
    MediaProjectionManager projectionManager;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(22),dp(28),dp(22),dp(20));
        root.setBackgroundColor(0xFFF8FAFC);
        TextView title=new TextView(this); title.setText("WordLens 英文字組助手"); title.setTextSize(24); title.setTypeface(null,1);
        root.addView(title);
        TextView desc=new TextView(this); desc.setText("持續識別指定區域內嘅英文字，並自動更新懸浮窗單字建議。首次需要授權螢幕擷取及懸浮窗。");
        desc.setTextSize(15); desc.setPadding(0,dp(12),0,dp(12)); root.addView(desc);
        Button start=new Button(this); start.setText("開始自動識別"); root.addView(start);
        Button stop=new Button(this); stop.setText("停止識別"); root.addView(stop);
        TextView note=new TextView(this); note.setText("使用方法：開始識別 → 同意 Android 螢幕擷取 → 喺預覽畫面框選一次區域。之後會每隔約 1 秒自動分析。部分遊戲可能會阻止螢幕擷取。");
        note.setTextSize(13); note.setPadding(0,dp(14),0,0); root.addView(note);
        start.setOnClickListener(v -> {
            if(!Settings.canDrawOverlays(this)) {
                startActivityForResult(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())),REQ_OVERLAY);
            } else requestCapture();
        });
        stop.setOnClickListener(v -> {
            stopService(new Intent(this,ContinuousCaptureService.class));
            stopService(new Intent(this,OverlayService.class));
            Toast.makeText(this,"已停止識別",Toast.LENGTH_SHORT).show();
        });
        setContentView(root);
    }
    void requestCapture(){ startActivityForResult(projectionManager.createScreenCaptureIntent(),REQ_CAPTURE); }
    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(req==REQ_OVERLAY){ if(Settings.canDrawOverlays(this)) requestCapture(); }
        else if(req==REQ_CAPTURE && res==RESULT_OK && data!=null){
            Intent i=new Intent(this,ContinuousCaptureService.class);
            i.putExtra("resultCode",res); i.putExtra("data",data);
            if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        }
    }
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
