package com.samwong.wordlens;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;

public class OverlayService extends Service {
    WindowManager wm; View panel;
    @Override public void onCreate(){super.onCreate();wm=(WindowManager)getSystemService(WINDOW_SERVICE);}
    @Override public int onStartCommand(Intent i,int flags,int id){
        String result=i==null?"":i.getStringExtra("result");if(result==null)result="";
        show(result);return START_NOT_STICKY;
    }
    void show(String text){
        if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}}
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(12),dp(8),dp(12),dp(8));box.setBackgroundColor(0xF21E293B);
        TextView head=new TextView(this);head.setText("WordLens · 拖動此處");head.setTextColor(Color.WHITE);head.setTypeface(null,1);box.addView(head);
        ScrollView scroll=new ScrollView(this);TextView body=new TextView(this);body.setText(text);body.setTextColor(Color.WHITE);body.setTextSize(13);body.setPadding(0,dp(8),0,dp(6));scroll.addView(body);
        box.addView(scroll,new LinearLayout.LayoutParams(-1,dp(250)));
        Button close=new Button(this);close.setText("關閉懸浮窗");box.addView(close);close.setOnClickListener(v->stopSelf());
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p=new WindowManager.LayoutParams(dp(300),WindowManager.LayoutParams.WRAP_CONTENT,type,
          WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);
        p.gravity=Gravity.TOP|Gravity.END;p.x=dp(8);p.y=dp(100);
        head.setOnTouchListener((v,e)->{return true;});
        panel=box;try{wm.addView(panel,p);}catch(Exception ignored){}
    }
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onDestroy(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
