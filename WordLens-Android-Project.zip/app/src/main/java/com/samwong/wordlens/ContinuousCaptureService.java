package com.samwong.wordlens;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import androidx.core.app.NotificationCompat;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.*;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.*;

public class ContinuousCaptureService extends Service {
    static final String CHANNEL="wordlens_capture";
    MediaProjection projection;
    VirtualDisplay display;
    ImageReader reader;
    TextRecognizer recognizer;
    Handler handler;
    boolean processing=false, stopped=false, selectionShown=false;
    long lastProcess=0;
    Rect selectedRect=null;
    String lastText="";
    int width,height,density;
    Runnable cropPrompt;

    @Override public void onCreate(){
        super.onCreate();
        handler=new Handler(Looper.getMainLooper());
        recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        createChannel();
        Notification n=new NotificationCompat.Builder(this,CHANNEL).setContentTitle("WordLens 正在識別")
          .setContentText("持續分析你選取嘅螢幕區域").setSmallIcon(android.R.drawable.ic_menu_search)
          .setOngoing(true).build();
        startForeground(31,n);
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && "SET_REGION".equals(intent.getAction())){
            float l=intent.getFloatExtra("left",0f), t=intent.getFloatExtra("top",0f);
            float r=intent.getFloatExtra("right",1f), b=intent.getFloatExtra("bottom",1f);
            selectedRect=new Rect((int)(l*width),(int)(t*height),(int)(r*width),(int)(b*height));
            return START_NOT_STICKY;
        }
        if(intent==null || !intent.hasExtra("data")){stopSelf();return START_NOT_STICKY;}
        int resultCode=intent.getIntExtra("resultCode",0);
        Intent data=intent.getParcelableExtra("data");
        DisplayMetrics dm=getResources().getDisplayMetrics();
        width=dm.widthPixels; height=dm.heightPixels; density=dm.densityDpi;
        projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(resultCode,data);
        reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,3);
        display=projection.createVirtualDisplay("WordLensContinuous",width,height,density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
        reader.setOnImageAvailableListener(this::onImage,handler);
        return START_NOT_STICKY;
    }
    void showSelectionPrompt(){
        Intent i=new Intent(this,CropActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
    }
    void onImage(ImageReader r){
        Image image=null;
        try{
            image=r.acquireLatestImage();
            if(image==null || processing)return;
            long now=System.currentTimeMillis();
            if(now-lastProcess<1000)return;
            lastProcess=now;
            Image.Plane plane=image.getPlanes()[0];
            ByteBuffer buffer=plane.getBuffer();
            int pixelStride=plane.getPixelStride(),rowStride=plane.getRowStride();
            Bitmap padded=Bitmap.createBitmap(width+(rowStride-pixelStride*width)/pixelStride,height,Bitmap.Config.ARGB_8888);
            padded.copyPixelsFromBuffer(buffer);
            Bitmap full=Bitmap.createBitmap(padded,0,0,width,height); padded.recycle();
            if(selectedRect==null) {
                if(!selectionShown) {
                    selectionShown=true;
                    CropActivity.bitmap=full.copy(Bitmap.Config.ARGB_8888,false);
                    Intent pick=new Intent(this,CropActivity.class);
                    pick.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(pick);
                }
                full.recycle();
                return;
            }
            Bitmap crop;
            Rect safe=new Rect(selectedRect);
            safe.intersect(0,0,width,height);
            if(safe.width()<2 || safe.height()<2){full.recycle();return;}
            crop=Bitmap.createBitmap(full,safe.left,safe.top,safe.width(),safe.height());
            full.recycle();
            processing=true;
            recognizer.process(InputImage.fromBitmap(crop,0))
              .addOnSuccessListener(result->{
                String txt=result.getText().trim();
                if(!txt.equals(lastText) && !txt.isEmpty()){
                    lastText=txt;
                    String suggestions=SuggestionFormatter.format(txt);
                    Intent overlay=new Intent(this,OverlayService.class);
                    overlay.putExtra("result",suggestions);
                    if(Build.VERSION.SDK_INT>=26)startService(overlay);else startService(overlay);
                }
              })
              .addOnFailureListener(e->{})
              .addOnCompleteListener(t->{crop.recycle();processing=false;});
        }catch(Exception e){processing=false;}
        finally{if(image!=null)image.close();}
    }
    static void setSelectedRect(Rect r){ /* selection is forwarded through service intent by CropActivity */ }
    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c=new NotificationChannel(CHANNEL,"WordLens 螢幕識別",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    @Override public void onDestroy(){
        stopped=true;
        if(reader!=null){reader.setOnImageAvailableListener(null,null);reader.close();}
        if(display!=null)display.release();
        if(projection!=null)projection.stop();
        if(recognizer!=null)recognizer.close();
        stopForeground(true);
        super.onDestroy();
    }
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
