package com.samwong.wordlens;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class WordFinder {
    private WordFinder() {}

    private static final String[] DATA = "a an and ant any ape are art as ask at ate bad bag ban bar bat bay bed bee beg bet big bin bit blue box boy bus but buy can cap car cat cow cry cup cut day den did die dig dog dot dry ear eat egg end eye fan far fat few fit fix fly fog for fox fun gap gas get god got gum gun guy ham has hat hay her hen hey hid him hip his hit hot how hug ice ill ink jam jar jet job joy key kid kit lab lad lag lap law lay led leg let lid lie lip lit log lot low mad man map mat may men met mix mob mom mud mug nap net new nod nor not now nut oak odd off oil old one our out own pad pal pan pat pay pea pen pet pie pig pin pit pot put rag ram ran rap rat raw red rid rig rim rip rob rod rot row rub rug run sad sag sat saw say sea see set sew she shy sin sip sit six sky sob son sun tag tan tap tar tea ten the tie tin tip toe top toy try tub two use van vat vet via war was wax way web wet who why wig win wit won yes yet you zip zoo able about above act add age ago aid aim air all also angel anger angle animal answer apple area arm around artist baby back bake ball band bank base basic bath beach bear beat become before begin behind believe best better between bird black block board boat body book born brain break bring brother build busy call came camera capital card care careful carry case catch cause cell center certain change charge check child choose city class clean clear close cloud cold color come common complete computer consider control cook cool copy corner correct cost could count country course cover create cross dark data date dead deal dear death decide deep develop did differ direct discover doctor door down draw dream dress drink drive drop during each early earth east easy edge effect effort eight either else end energy enjoy enough enter equal especially even ever every example face fact fall family fast father fear feel feet field fight figure fill film final find fine finger finish fire first fish five floor flower follow food foot force form found four free friend front full game garden gave general girl give glass goal gold good government great green ground group grow guess half hand happen happy hard head health hear heart heat heavy help here high history hold home hope horse hour house human hundred idea image important include increase indeed information inside instead interest island job join just keep kind king know land language large last late later laugh lead learn least leave left less letter level life light like line list listen little live local long look lose love made main make many mark market matter mean measure meet member might mind minute model modern moment money month more morning most mother move much music must name nation natural near need never next night north note nothing notice number object ocean offer office often once only open option order other over page paper parent part party pass past people perhaps person picture place plan play player played playing plays point power present problem process produce product program public pull question quick quite race radio rain raise reach read ready real reason receive record remain remember report rest result return right river road rock room round rule said same save school science second seem sell send sense serve several short should show side simple since sing sister size sleep small snow social some song soon sound south space speak special spell spend sport stand start state stay step still stop story street strong study such summer sure system table take talk tell test than thank that their them then there these they thing think this those though thought three through time today together told took top toward town tree true turn under understand until upon usual very view visit voice wait walk wall want warm watch water wear weather week well went were west what when where which while white whole wide wife will wind window wish with within without woman word work world would write wrong year young").split());
    private static final Set<String> WORDS = new HashSet<>(Arrays.asList(DATA));
    private static final String[] PREFIX = {"re", "un", "dis", "mis", "pre", "over", "under", "out", "non", "de", "en", "in", "im"};
    private static final String[] SUFFIX = {"s", "es", "ed", "ing", "er", "est", "ly", "y", "able", "ful", "less", "ness", "ment", "tion", "ation", "al", "ous", "ive", "ity", "ist", "ize", "ise", "en"};

    public static List<String> find(String raw) {
        String w = raw == null ? "" : raw.toLowerCase().replaceAll("[^a-z]", "".split("\\s+");
        if (w.isEmpty()) return Collections.emptyList();
        Set<String> out = new HashSet<>();
        for (String x : WORDS) {
            if (x.length() > w.length() && (x.startsWith(w) || x.endsWith(w) || x.contains(w))) out.add(x);
        }
        for (String p : PREFIX) if (WORDS.contains(p + w)) out.add(p + w);
        for (String s : SUFFIX) if (WORDS.contains(w + s)) out.add(w + s);
        List<String> result = new ArrayList<>(out);
        Collections.sort(result);
        return result;
    }
}
