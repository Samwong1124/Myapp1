# WordLens Android Project

這是 Android 專案原始碼，供 GitHub Actions 自動編譯 APK 使用。

## GitHub 手機上傳方式
1. 在 GitHub repository 根目錄上傳本 ZIP 檔，檔名建議為 `WordLens-Android-Project.zip`。
2. 確認 repository 已經有 `.github/workflows/build.yml`（另行提供的 build.yml 需放在該路徑）。
3. 到 Actions 執行 `Build WordLens APK`。
4. 完成後從 Artifacts 下載 `WordLens-debug-APK`。

## 功能狀態
專案包含螢幕擷取、選區畫面、ML Kit OCR、單字建議和懸浮窗的原型程式碼。
此原型尚未在實機上驗證完整操作流程；編譯成功不等於所有功能已通過實機測試。
