# WordLens 英文字組助手 — 持續識別原型

## 功能目標
- Android MediaProjection 擷取畫面
- 使用者首次選取識別區域
- ML Kit OCR 識別英文
- OCR 文字變化時更新懸浮窗
- GitHub Actions 自動編譯 debug APK

## 編譯
推送到 GitHub 的 `main` 或 `master` 分支，或到 Actions 手動執行 `Build WordLens APK`。完成後在 workflow run 的 Artifacts 下載 `WordLens-debug-APK`。

## 重要原型限制
此 ZIP 是可供 GitHub Actions 編譯與後續測試的原型，尚未經過裝置端整合測試。已加入擷取首幀預覽、選區座標傳回與持續 OCR 的初步實作，但 MediaProjection 生命週期、Android 版本相容性及懸浮窗更新仍需要實機驗證。
字典只含一小部分常用詞，未能列出所有英文單字。螢幕擷取需要使用者明確授權，部分應用會封鎖截圖。
